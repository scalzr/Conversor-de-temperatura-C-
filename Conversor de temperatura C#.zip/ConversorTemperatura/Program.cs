﻿using System;

namespace ConversorTemperatura
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Conversor de Temperatura");

            // Entrada da temperatura
            Console.Write("Digite a temperatura: ");
            double temperatura = Convert.ToDouble(Console.ReadLine());

            // Entrada da unidade de origem
            Console.WriteLine("Escolha a unidade de origem:");
            Console.WriteLine("1: Celsius");
            Console.WriteLine("2: Fahrenheit");
            Console.WriteLine("3: Kelvin");
            int unidadeOrigem = Convert.ToInt32(Console.ReadLine());

            // Variáveis para armazenar os resultados das conversões
            double celsius, fahrenheit, kelvin;

            switch (unidadeOrigem)
            {
                case 1: // Celsius
                    celsius = temperatura;
                    fahrenheit = CelsiusParaFahrenheit(temperatura);
                    kelvin = CelsiusParaKelvin(temperatura);
                    break;
                case 2: // Fahrenheit
                    celsius = FahrenheitParaCelsius(temperatura);
                    fahrenheit = temperatura;
                    kelvin = FahrenheitParaKelvin(temperatura);
                    break;
                case 3: // Kelvin
                    celsius = KelvinParaCelsius(temperatura);
                    fahrenheit = KelvinParaFahrenheit(temperatura);
                    kelvin = temperatura;
                    break;
                default:
                    Console.WriteLine("Unidade de origem inválida!");
                    return;
            }

            // Exibição dos resultados
            Console.WriteLine($"Celsius: {celsius:F2}");
            Console.WriteLine($"Fahrenheit: {fahrenheit:F2}");
            Console.WriteLine($"Kelvin: {kelvin:F2}");
        }

        // Funções de conversão
        static double CelsiusParaFahrenheit(double celsius)
        {
            return celsius * 9 / 5 + 32;
        }

        static double CelsiusParaKelvin(double celsius)
        {
            return celsius + 273.15;
        }

        static double FahrenheitParaCelsius(double fahrenheit)
        {
            return (fahrenheit - 32) * 5 / 9;
        }

        static double FahrenheitParaKelvin(double fahrenheit)
        {
            return (fahrenheit - 32) * 5 / 9 + 273.15;
        }

        static double KelvinParaCelsius(double kelvin)
        {
            return kelvin - 273.15;
        }

        static double KelvinParaFahrenheit(double kelvin)
        {
            return (kelvin - 273.15) * 9 / 5 + 32;
        }
    }
}

